# VideoEdit
使用OpenCV和Qt实现的视频编辑器

环境：
win10
vs2017+Qt5.14+ffmpeg+opencv3.4

由于文件大小限制，bin文件夹中缺少opencv_world340.dll
