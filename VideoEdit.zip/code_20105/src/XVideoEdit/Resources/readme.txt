PlayN 表示正常播放状态（normal）
PlayH 表示播放时鼠标移到上面状态（hover)
PlayP 表示按压状态（pressed）